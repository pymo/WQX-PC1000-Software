void drawG(int ID, int x, int y, int mode)
{
	int i, j, k, com;
	unsigned char d;
	
	com=8-gObj[ID].width+gObj[ID].w0;
	if(mode==TRANSPARENT || mode==INVERSED_T)
	{
		for(i=0; i<gObj[ID].height; i++)
			for(j=0; j<gObj[ID].width/8; j++)
			{
				if(mode==INVERSED_T)
					d=~(gObj[ID].dataPtr)[i*(gObj[ID].width/8)+j];
				else
					d=(gObj[ID].dataPtr)[i*(gObj[ID].width/8)+j];
	
				for(k=7; d!=0 && k>=0; k--, d/=2)
					if(!(j==gObj[ID].width/8-1 && k>=com))
						if(d%2==1)
							putpixel(x+j*8+k, y+i, 1);
			}
	}
	else if(mode==SOLID || mode==INVERSED_S)
	{
		for(i=0; i<gObj[ID].height; i++)
			for(j=0; j<gObj[ID].width/8; j++)
			{
				if(mode==INVERSED_S)
					d=~(gObj[ID].dataPtr)[i*(gObj[ID].width/8)+j];
				else
					d=(gObj[ID].dataPtr)[i*(gObj[ID].width/8)+j];
	
				for(k=7; k>=0; k--, d/=2)
					if(!(j==gObj[ID].width/8-1 && k>=com))
						putpixel(x+j*8+k, y+i, d % 2);
			}
	}
}