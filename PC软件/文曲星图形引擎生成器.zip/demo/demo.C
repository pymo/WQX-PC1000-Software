//-------------------------------GRAPHIC ENGIN-------------------------------
//--------------------------COPYRIGHTED BY LIUYIDAO--------------------------
#include <stdio.h>
#include <system.h>
#define LCD_BUFFER_BASEADDR		0x9c0
#define SCREENWIDTH_IN_BYTE 10
#define TRANSPARENT	0 
#define SOLID		1 
#define INVERSED_T	2 
#define INVERSED_S	3 

#define DEMO1 0
#define DEMO2 1
#define DEMO3 2
#define DEMO4 3
#define AUTHOR 4

typedef struct
{
	int width, height, w0;
	unsigned char *dataPtr;
} graph_t;

//-------------------------------function prototypes-------------------------------
void drawG(int ID, int x, int y, int mode);
void getSize(int ID, int *width, int *height);
void initializeG(void);

//-------------------------------Graphic Objects declaration-------------------------------
extern graph_t gObj[5]={{16,10,11},{24,14,23},{16,14,15},{16,14,16},{152,27,145}};
//-------------------------------Graphic Data Storage-------------------------------
extern unsigned char gdata_DEMO1[20]={142,32,49,128,65,64,66,64,132,32,134,32,65,64,64,64,49,128,142,32};
extern unsigned char gdata_DEMO2[42]={255,255,254,255,255,254,255,255,254,255,255,254,255,255,254,255,255,254,255,255,254,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
extern unsigned char gdata_DEMO3[28]={255,254,255,254,192,6,192,6,192,6,192,6,192,6,192,6,192,6,192,6,192,6,192,6,255,254,255,254};
extern unsigned char gdata_DEMO4[28]={7,224,31,248,63,252,127,254,126,126,252,63,248,31,248,31,252,63,126,126,127,254,63,252,31,248,7,224};
extern unsigned char gdata_AUTHOR[513]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,128,0,0,0,0,0,0,1,224,0,0,0,0,0,0,0,0,1,129,192,0,0,0,0,0,0,0,224,0,0,0,0,0,0,0,0,1,195,128,0,0,28,0,0,6,0,0,0,0,0,0,0,0,63,0,1,195,128,0,15,255,0,0,7,128,62,0,0,0,0,0,15,247,128,3,135,0,0,14,14,0,0,3,131,252,0,0,0,0,0,255,7,128,3,135,0,0,14,14,0,0,0,63,0,0,0,0,0,0,3,135,0,7,14,63,128,6,12,0,0,0,3,128,0,0,0,0,0,7,135,0,6,15,240,0,6,12,0,0,48,7,56,0,0,0,0,0,7,7,0,15,31,128,0,6,62,0,0,28,6,28,0,0,0,0,0,7,7,0,31,57,128,0,7,224,0,0,28,15,252,0,0,0,252,0,14,7,0,59,49,128,0,3,0,0,0,0,31,12,0,0,255,254,0,14,6,0,115,97,158,0,0,0,0,0,0,24,48,3,255,252,6,0,28,14,0,227,193,248,0,0,0,48,0,1,128,48,0,240,0,0,0,28,14,1,131,1,128,0,7,63,248,0,1,187,176,0,0,0,0,0,56,14,0,3,1,128,3,255,184,60,0,3,27,176,0,0,0,0,0,112,14,0,3,1,128,1,135,152,48,0,3,27,176,0,0,0,0,0,224,28,0,3,1,254,1,199,24,112,0,7,59,48,96,0,0,0,1,192,220,0,3,1,224,1,199,24,96,0,14,51,48,96,0,0,0,3,128,252,0,3,1,128,0,198,24,240,0,30,115,56,224,0,0,0,6,0,120,0,3,1,128,0,255,31,240,0,28,99,31,224,0,0,0,0,0,112,0,3,1,128,0,224,24,0,0,12,192,15,192,0,0,0,0,0,96,0,3,1,128,0,192,24,0,0,1,128,0,0,0,0,0,0,0,0,0,0,1,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

//-------------------------------Functions-------------------------------
void initializeG()
{
	gObj[DEMO1].dataPtr=gdata_DEMO1;
	gObj[DEMO2].dataPtr=gdata_DEMO2;
	gObj[DEMO3].dataPtr=gdata_DEMO3;
	gObj[DEMO4].dataPtr=gdata_DEMO4;
	gObj[AUTHOR].dataPtr=gdata_AUTHOR;
}
void getSize(int ID, int *width, int *height)
{
	*width=gObj[ID].w0;
	*height=gObj[ID].height;
}
void drawG(int ID, int x, int y, int mode)
{
	int i, j, k, com;
	unsigned char d;
	
	com=8-gObj[ID].width+gObj[ID].w0;
	if(mode==TRANSPARENT || mode==INVERSED_T)
	{
		for(i=0; i<gObj[ID].height; i++)
			for(j=0; j<gObj[ID].width/8; j++)
			{
				if(mode==INVERSED_T)
					d=~(gObj[ID].dataPtr)[i*(gObj[ID].width/8)+j];
				else
					d=(gObj[ID].dataPtr)[i*(gObj[ID].width/8)+j];
	
				for(k=7; d!=0 && k>=0; k--, d/=2)
					if(!(j==gObj[ID].width/8-1 && k>=com))
						if(d%2==1)
							putpixel(x+j*8+k, y+i, 1);
			}
	}
	else if(mode==SOLID || mode==INVERSED_S)
	{
		for(i=0; i<gObj[ID].height; i++)
			for(j=0; j<gObj[ID].width/8; j++)
			{
				if(mode==INVERSED_S)
					d=~(gObj[ID].dataPtr)[i*(gObj[ID].width/8)+j];
				else
					d=(gObj[ID].dataPtr)[i*(gObj[ID].width/8)+j];
	
				for(k=7; k>=0; k--, d/=2)
					if(!(j==gObj[ID].width/8-1 && k>=com))
						putpixel(x+j*8+k, y+i, d % 2);
			}
	}
}
/********************************  Main()  ***************************/
void main(void)
{
//Variable delaration here
	int i;


//initailize graphic data
	initializeG();


//Your own process here

	ClearScreen();
	for(i=0; i<=70; i+=20)
		drawG(DEMO2, 30+i, 8, SOLID);

	drawG(DEMO1, 10, 10, SOLID);
	drawG(DEMO1, 30, 10, TRANSPARENT);
	drawG(DEMO1, 50, 10, SOLID);
	drawG(DEMO1, 70, 10, INVERSED_T);
	drawG(DEMO1, 90, 10, INVERSED_S);
	sleep(10);

	ClearScreen();
	drawG(DEMO3, 30, 30, SOLID);
	sleep(5);
	drawG(DEMO4, 80, 30, SOLID);
	sleep(10);

	ClearScreen();
	drawG(DEMO3, 30, 30, SOLID);
	sleep(5);
	drawG(DEMO4, 30, 30, SOLID);
	sleep(10);

	ClearScreen();
	drawG(DEMO3, 30, 30, SOLID);
	sleep(5);
	drawG(DEMO4, 30, 30, TRANSPARENT);
	sleep(10);

  	ClearScreen();
	drawG(DEMO3, 30, 30, INVERSED_S);
	sleep(5);
	drawG(DEMO4, 80, 30, INVERSED_S);
	sleep(10);

   	ClearScreen();
	drawG(DEMO3, 30, 30, INVERSED_S);
	sleep(5);
	drawG(DEMO4, 30, 30, INVERSED_S);
	sleep(10);

   	ClearScreen();
	drawG(DEMO3, 30, 30, INVERSED_S);
	sleep(5);
	drawG(DEMO4, 30, 30, INVERSED_T);
	sleep(10);

	while(1)
	{
	ClearScreen();
	drawG(AUTHOR, 5, 26, SOLID);
	sleep(10);
	drawG(AUTHOR, 5, 26, INVERSED_S);
	sleep(10);
	}
}
/******************************  End of Main()  ***********************/
